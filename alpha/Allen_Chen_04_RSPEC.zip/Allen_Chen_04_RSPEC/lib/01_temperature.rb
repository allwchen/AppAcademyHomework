def ftoc (fahr)
  return (fahr-32)*5.0/9
end

def ctof (cels)
  return cels*9.0/5+32
end
