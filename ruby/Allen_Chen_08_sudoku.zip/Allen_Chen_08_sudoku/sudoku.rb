require_relative "board"

class SudokuGame
  attr_reader :board

  def self.from_file (filename)
    board = Board.from_file(filename)
    self.new(board)
  end

  def initialize(board)
    @board = board
  end

  def get_position
    pos = nil
    until pos && validate_pos(pos)
      pos = prompt_position
    end
    pos
  end

  def get_value
    value = nil
    until value && validate_value(value)
      value = prompt_value
    end
    value.to_i
  end

  def prompt_position
    puts "Enter a position (e.g. 3 4)"
    print "> "
    pos = gets.chomp.split
    return pos
  end

  def prompt_value
    puts "Enter a value for that position (1-9)"
    print "> "
    value = gets.chomp
    return value
  end

  def validate_pos(pos)
    if bad_position(pos)
      puts "Position #{pos} is not valid. Must be valid indices from 0-8."
      return false
    else
      pos.map!(&:to_i) #need to do this here because to_i maps letters to 0
    end
    if given_position(pos)
      puts "Position #{pos} is not valid. This is position's value is given."
      return false
    end
    return true
  end

  def validate_value(value)
    if !(1..9).map(&:to_s).include?(value)
      puts "Value <#{value}> is not valid. Must be a number from 1-9."
      return false
    end
    return true
  end

  def bad_position(pos)
    row, col = pos
    valid_numbers = (0..8).map(&:to_s)
    return true if row.nil? || col.nil?
    return true if !valid_numbers.include?(row) || !valid_numbers.include?(col)
    return false
  end

  def given_position(pos)
    tile = board[pos]
    return tile.given?
  end

  def play
    until board.solved?
      board.render
      pos = get_position
      value = get_value
      board.update_value_at(pos, value)
    end
    board.render
    puts "Congratulations! You have solved the puzzle."
  end
end
