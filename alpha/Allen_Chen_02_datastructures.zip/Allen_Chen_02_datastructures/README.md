# Data Structures Exercises

Fill in each of the method bodies. Instructions for each method are in the comments.

We give the expert problem to our App Academy students. It's very difficult!
