# recursion

This project is about recursion.

This project has tests to help you check your answers.
To run the tests, first navigate to the root directory of the project and run `bundle install` to install rspec.
Then, each time you want to run the tests, run `bundle exec rspec`.
