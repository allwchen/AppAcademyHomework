require_relative "tile"
require "byebug"

class Board
  attr_reader :grid

  def self.empty_grid
    Array.new(9) do
      Array.new(9) { Tile.new(0) }
    end
  end

  def self.from_file(filename="sudoku_puzzles/sudoku1.txt")
    rows = File.readlines(filename).map(&:chomp)
    tiles = rows.map do |row|
      nums = row.split("").map { |char| Integer(char) }
      nums.map { |num| Tile.new(num) }
    end
    self.new(tiles)
  end

  def initialize(grid = Board.empty_grid)
    @grid = grid
  end

  # def initialize(filename="sudoku_puzzles/sudoku1.txt")
  #   @grid = Array.new(9)
  #   File.open(filename).each_line.with_index do |line, idx|
  #     @grid[idx] = []
  #     line.chomp.split("").each { |num| @grid[idx] << Tile.new(num.to_i) }
  #   end
  #   return self
  # end

  def update_value_at(position, value)
    # row, col = position
    tile = self[position]
    if tile.given == false
      tile.value = value
      return true
    else
      return false
    end
  end

  def [](pos)
    row, col = pos
    grid[row][col]
  end

  def []=(pos, value)
    row, col = pos
    grid[row][col] = value
  end

  def render
    grid.each_with_index do |row, row_idx|
      row.each_with_index do |tile, col_idx|
        print tile.to_s + " "
        print "  " if (col_idx + 1)%3==0
      end
      puts
      puts if (row_idx+1)%3==0
    end
    ""
  end

  def solved?
    all_filled? && rows_solved? && cols_solved? && squares_solved?
  end

  def all_filled?
    grid.each do |row|
      row.each do |tile|
        return false if tile.value==0
      end
    end
    return true
  end

  def rows_solved?
    grid.each do |row|
      tile_values = []
      row.each do |tile|
        tile_values << tile.value
      end
      return false if !tile_values.is_unique?
    end
    return true
  end

  def cols_solved?
    col_arrays = []
    grid.each_with_index do |row, row_idx|
      row.each_with_index do |tile, col_idx|
        col_arrays[col_idx] = [] if row_idx == 0
        col_arrays[col_idx] << tile.value
      end
    end
    col_arrays.each do |arr|
      return false if !arr.is_unique?
    end
    return true
  end

  #   0 1 2 3 4 5 6 7 8
  # 0 0 0 0 1 1 1 2 2 2
  # 1 0 0 0 1 1 1 2 2 2
  # 2 0 0 0 1 1 1 2 2 2
  # 3 3 3 3 4 4 4 5 5 5
  # 4 3 3 3 4 4 4 5 5 5
  # 5 3 3 3 4 4 4 5 5 5
  # 6 6 6 6 7 7 7 8 8 8
  # 7 6 6 6 7 7 7 8 8 8
  # 8 6 6 6 7 7 7 8 8 8
  def squares_solved?
    sq_arrays = []
    grid.each_with_index do |row, row_idx|
      row.each_with_index do |tile, col_idx|
        sq_arrays[row_idx/3*3 + col_idx/3] = [] if row_idx % 3 == 0 && col_idx % 3 == 0
        sq_arrays[row_idx/3*3 + col_idx/3] << tile.value
      end
    end
    sq_arrays.each do |arr|
      return false if !arr.is_unique? #arr.uniq? != arr.uniq
    end
    return true
  end

end

class Array
  def is_unique?
    self == self.uniq
  end
end
